<?php
namespace Adfab\Gdpr\Controller\Delete;

class Index extends \Adfab\Gdpr\Controller\Privacy
{
    /**
     * Managing newsletter subscription page
     *
     * @return void
     */
    public function execute()
    {
        // TODO : find suitable format
        die('To implement');
    }
}
